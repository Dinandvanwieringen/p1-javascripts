function kleur_aanpassen() {
    document.getElementById("text").style.color = "blue";   
}

kleur_aanpassen()
